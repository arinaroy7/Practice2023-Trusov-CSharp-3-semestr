namespace YourNamespace
{
    public class UserWithTotalPrice
    {
        public int UserId { get; set; }
        public string? Login { get; set; }
        public decimal TotalPrice { get; set; }
    }
}